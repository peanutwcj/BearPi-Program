### 这种算法理解简单，实现简单，但是算法**时间复杂度秒变为O(n)**，当n很大时，插入一个节点的时间就会非常久。4.1. 软件定时器设计思想

MultiTimer的设计比较简洁。

设置一个计数值`_timer_ticks`不断递增，由定时器提供的中断驱动，只计次数，不计时间，有了很大的自由度，一般时基信号设置为1ms一次：

void timer_ticks(){  _timer_ticks++;}

在程序运行时循环比较定时器设置的超时值是否大于当前_timer_ticks的计数值，如果是则再次判断是否重复计数值是否为0，是则停止定时器，完成单次计时效果，否则修改计数值，最后拉起注册到该定时器的回调函数执行：

```c
/**  * @brief  main loop.  * @param  None.  * @retval None  */void timer_loop(){  struct Timer* target;  for(target=head_handle; target; target=target->next) {    if(_timer_ticks >= target->timeout) {      if(target->repeat == 0) {        timer_stop(target);      } else {        target->timeout = _timer_ticks + target->repeat;      }      target->timeout_cb();    }  }}
```

### 4.2. 单链表操作

MultiTimer的代码少，非常适合拿来学习单链表的操作，学习数据结构的过程是乏味的，不如直接来个实例看看是如何操作的。

① 链表的**节点设计为一个软件定时器**，所以理论上支持的定时器数量只受内存限制。

```c
typedef struct Timer {   
uint32_t timeout;    
uint32_t repeat;    
void (*timeout_cb)(void);    
struct Timer* next;
}Timer;

```

 定时器初始化函数`timer_init`就是初始化一个链表节点：

```c
void timer_init(struct Timer* handle, void(*timeout_cb)(), uint32_t timeout, uint32_t repeat){  // memset(handle, sizeof(struct Timer), 0);  handle->timeout_cb = timeout_cb;  handle->timeout = _timer_ticks + timeout;  handle->repeat = repeat;}
```

② 设置**链表头指针**，只需知道头指针就能完成对整个单链表的操作：

```c
//timer handle list head.
static struct Timer* head_handle = NULL;
```

③ 向单链表**增加一个节点**

向单链表增加一个节点有三种方式：

- 在单链表尾部增加一个节点

- 在单链表头部增加一个节点

- 在单链表中间增加一个节点

  MultiTimer中所有的结点都是定时器，每个定时器之间相互独立，不存在先后次序关系，所以无论加到中间，还是加到尾部，还是加到头部，最后的功能都是一样的，但是在插入算法上有优劣性能之分。

```c
int timer_start(struct Timer* handle){  /**    * 算法1 —— 向单链表尾部添加节点   * 时间复杂度O(n)   * Mculover666   */  struct Timer* target = head_handle;  if(head_handle == NULL)  {    /* 链表为空 */    head_handle = handle;    handle->next = NULL;  }  else  {    /* 链表中存在节点，遍历找最后一个节点 */    while(target->next != NULL)    {      if(target == handle)        return -1;      target = target->next;    }    target->next = handle;    handle->next = NULL;  }    return 0;}
```

这种算法理解简单，实现简单，但是算法**时间复杂度秒变为O(n)**，当n很大时，插入一个节点的时间就会非常久。

再来看看在链表头部插入一个新节点的情况：

```c
int timer_start(struct Timer* handle){  /**    * 算法2 —— 向单链表头部添加节点   * 时间复杂度O(n)，如果去掉判断重复，则时间复杂度O(1)   * 0x1abin   */   struct Timer *target = head_handle;      //判断是否有重复的定时器   while(target)   {    if(target == handle)    {      return -1;    }    target = target->next;   }   handle->next = head_handle;   head_handle = handle;   return 0;}
```

这里第二种头部插入节点的算法时间复杂度依然是O(n)，emmm?

其实，这里因为单链表节点是定时器，**在插入的时候需要对整个链表进行判断，避免重复添加同样的定时器节点**，所以无论任何一种算法，都需要对单链表进行遍历。

如果在不需要判断重复的情况下，尾部插入算法仍然需要遍历，但是**头部插入算法只需要插入就可以，时间复杂度为O(1)，算法更优**。

④ 单链表**删除其中一个节点**

删除单链表的节点时，因为节点自身只保存有下一个节点的指针，并没有指向上一个节点的指针，所以不能直接入手删除节点，那么如何删除单链表的节点呢？

方法是：设置二级指针（指向Timer类型指针的指针），通过遍历链表的方式来寻找**节点中next指针指向删除节点的**那个节点，代码如下。

```c
void timer_stop(struct Timer* handle){  struct Timer** curr;  for(curr = &head_handle; *curr; ) {    struct Timer* entry = *curr;    if (entry == handle) {      *curr = entry->next;//      free(entry);    } else      curr = &entry->next;  }}
```