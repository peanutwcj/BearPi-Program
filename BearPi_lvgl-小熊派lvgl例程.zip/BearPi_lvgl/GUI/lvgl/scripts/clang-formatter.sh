clang-format-7 -style=file ../src/lv_core/*.c -i
clang-format-7 -style=file ../src/lv_draw/*.c -i
clang-format-7 -style=file ../src/lv_hal/*.c -i
clang-format-7 -style=file ../src/lv_misc/*.c -i
clang-format-7 -style=file ../src/lv_objx/*.c -i
clang-format-7 -style=file ../src/lv_themes/*.c -i

clang-format-7 -style=file ../src/lv_core/*.h -i
clang-format-7 -style=file ../src/lv_draw/*.h -i
clang-format-7 -style=file ../src/lv_hal/*.h -i
clang-format-7 -style=file ../src/lv_misc/*.h -i
clang-format-7 -style=file ../src/lv_objx/*.h -i
clang-format-7 -style=file ../src/lv_themes/*.h -i
